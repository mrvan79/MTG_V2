package com.juneutf.mtg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtgApplicationTests {

	@Test
	void contextLoads() {
	}

}
